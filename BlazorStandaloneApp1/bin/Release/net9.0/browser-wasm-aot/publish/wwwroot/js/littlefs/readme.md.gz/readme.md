# littlefs-pure-js

LittleFS partially ported over to pure JavaScript. This was ported over just enough to generate a LittleFS partition and to add files and folders to it.
